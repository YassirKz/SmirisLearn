// src/components/admin/pillars/CreatePillarModal.jsx
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    X, Sparkles, Save, Eye
} from 'lucide-react';
import { supabase } from '../../../lib/supabase';
import { useAuth } from '../../../hooks/useAuth';
import { useToast } from '../../ui/Toast';
import SanitizedInput from '../../ui/SanitizedInput';

// Icônes disponibles
const ICONS = ['📚', '🎓', '💻', '📊', '🎯', '⚡', '🌟', '🔥', '💡', '🎨', '📝', '🔬'];

// Couleurs disponibles
const COLORS = [
    { name: 'primary', class: 'bg-primary-500', gradient: 'from-primary-600 to-primary-800' },
    { name: 'accent', class: 'bg-accent-500', gradient: 'from-accent-600 to-indigo-600' },
    { name: 'purple', class: 'bg-purple-500', gradient: 'from-purple-500 to-pink-600' },
    { name: 'green', class: 'bg-green-500', gradient: 'from-green-500 to-emerald-600' },
    { name: 'red', class: 'bg-red-500', gradient: 'from-red-500 to-pink-600' },
    { name: 'yellow', class: 'bg-yellow-500', gradient: 'from-yellow-500 to-orange-600' },
    { name: 'pink', class: 'bg-pink-500', gradient: 'from-pink-500 to-rose-600' },
    { name: 'orange', class: 'bg-orange-500', gradient: 'from-orange-500 to-red-600' }
];

export default function CreatePillarModal({ isOpen, onClose, onSuccess, orgId: propOrgId }) {
    const { user } = useAuth();
    const { success, error: showError } = useToast();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        description: '',
        icon: '📚',
        color: 'primary'
    });
    const [touched, setTouched] = useState({});
    const [previewMode, setPreviewMode] = useState(false);

    const validateForm = () => {
        const errors = {};
        if (!formData.name) errors.name = "Ce champ est obligatoire";
        else if (formData.name.length < 3) errors.name = "Minimum 3 caractères";
        else if (formData.name.length > 50) errors.name = "Maximum 50 caractères";
        
        if (formData.description && formData.description.length > 200) {
            errors.description = "La description ne peut pas dépasser 200 caractères";
        }
        return errors;
    };

    const errors = validateForm();
    const isValid = Object.keys(errors).length === 0;

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!isValid || loading) return;

        setLoading(true);
        try {
            let orgId = propOrgId;
            if (!orgId) {
                const { data: profile } = await supabase
                    .from('profiles')
                    .select('organization_id')
                    .eq('id', user.id)
                    .single();
                orgId = profile?.organization_id;
            }

            if (!orgId) throw new Error("ID d'organisation non trouvé");

            const { error } = await supabase
                .from('pillars')
                .insert({
                    organization_id: orgId,
                    name: formData.name.trim(),
                    description: formData.description.trim() || null,
                    icon: formData.icon,
                    color: formData.color
                });

            if (error) throw error;

            success("Pilier créé avec succès");
            onSuccess?.();
            onClose();
        } catch (err) {
            console.error('Erreur création pilier:', err);
            showError(err.message || 'Erreur lors de la création');
        } finally {
            setLoading(false);
        }
    };

    if (!isOpen) return null;

    const selectedColor = COLORS.find(c => c.name === formData.color) || COLORS[0];

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-50 overflow-y-auto">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-black/40 dark:bg-black/60 backdrop-blur-md"
                        onClick={onClose}
                    />

                    <div className="min-h-screen px-4 text-center">
                        <span className="inline-block h-screen align-middle">&#8203;</span>

                        <motion.div
                            initial={{ opacity: 0, scale: 0.9, y: 40 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.9, y: 40 }}
                            className="relative inline-block w-full max-w-2xl my-8 text-left align-middle"
                        >
                            <div className="relative bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 dark:border-gray-800 overflow-hidden">
                                {/* Éléments décoratifs */}
                                <div className="absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-br from-primary-400 to-accent-400 rounded-full opacity-20 blur-3xl" />
                                <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-gradient-to-br from-pink-400 to-orange-400 rounded-full opacity-20 blur-3xl" />

                                {/* Badge premium */}
                                <div className="absolute top-4 right-4 z-10">
                                    <div className="bg-gradient-to-r from-primary-600 to-accent-600 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 shadow-lg">
                                        <Sparkles className="w-3 h-3" />
                                        Nouveau pilier
                                    </div>
                                </div>

                                {/* En-tête */}
                                <div className={`relative px-8 pt-8 pb-6 bg-gradient-to-br ${selectedColor.gradient} text-white`}>
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-4">
                                            <div className="text-4xl">{formData.icon}</div>
                                            <div>
                                                <h2 className="text-2xl font-bold">
                                                    Créer un nouveau pilier
                                                </h2>
                                                <p className="text-white/80 text-sm mt-1">
                                                    Définissez un nouvel axe de formation
                                                </p>
                                            </div>
                                        </div>
                                        <button
                                            onClick={onClose}
                                            className="p-2 hover:bg-white/20 rounded-xl transition-all"
                                        >
                                            <X className="w-5 h-5" />
                                        </button>
                                    </div>

                                    <button
                                        onClick={() => setPreviewMode(!previewMode)}
                                        className="absolute bottom-6 right-8 flex items-center gap-2 px-3 py-1.5 bg-white/20 rounded-lg hover:bg-white/30 transition-all text-sm"
                                    >
                                        <Eye className="w-4 h-4" />
                                        {previewMode ? "Mode Édition" : "Aperçu"}
                                    </button>
                                </div>

                                {/* Corps */}
                                {previewMode ? (
                                    <div className="p-8">
                                        <div className={`bg-gradient-to-br ${selectedColor.gradient} rounded-2xl p-8 text-white shadow-xl`}>
                                            <div className="text-6xl mb-4">{formData.icon}</div>
                                            <h3 className="text-2xl font-bold mb-2">
                                                {formData.name || "Nom du pilier"}
                                            </h3>
                                            <p className="text-white/80">
                                                {formData.description || "Décrivez brièvement ce que contient ce pilier..."}
                                            </p>
                                            <div className="mt-4 flex gap-2">
                                                <span className="px-3 py-1 bg-white/20 rounded-full text-sm">
                                                    0 Vidéos
                                                </span>
                                                <span className="px-3 py-1 bg-white/20 rounded-full text-sm">
                                                    0 Étudiants
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <form onSubmit={handleSubmit} className="p-8 space-y-6">
                                        <SanitizedInput
                                            label="Nom du pilier"
                                            value={formData.name}
                                            onChange={(e) => handleChange('name', e.target.value)}
                                            onBlur={() => setTouched({ ...touched, name: true })}
                                            validate="text"
                                            minLength={3}
                                            maxLength={50}
                                            required
                                            error={touched.name ? errors.name : ''}
                                            placeholder="Ex: Management, Communication, Vente..."
                                            className="w-full px-4 py-3 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-primary-400 dark:focus:border-primary-500 focus:ring-4 focus:ring-primary-100 dark:focus:ring-primary-900/30 outline-none transition-all resize-none dark:text-white"
                                        />

                                        <div className="space-y-2">
                                            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300">
                                                Description
                                                <span className="text-gray-400 dark:text-gray-500 text-xs ml-2">(Optionnel)</span>
                                            </label>
                                            <textarea
                                                value={formData.description}
                                                onChange={(e) => handleChange('description', e.target.value)}
                                                onBlur={() => setTouched({ ...touched, description: true })}
                                                rows={3}
                                                className="w-full px-4 py-3 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-primary-400 dark:focus:border-primary-500 focus:ring-4 focus:ring-primary-100 dark:focus:ring-primary-900/30 outline-none transition-all resize-none dark:text-white"
                                                placeholder="Décrivez brièvement ce que contient ce pilier..."
                                            />
                                            <div className="flex justify-end">
                                                <span className={`text-xs ${(formData.description?.length || 0) > 180 ? 'text-orange-500 dark:text-orange-400' : 'text-gray-400 dark:text-gray-500'}`}>
                                                    {formData.description?.length || 0}/200
                                                </span>
                                            </div>
                                        </div>

                                        {/* Icône */}
                                        <div className="space-y-2">
                                            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300">
                                                Icône
                                            </label>
                                            <div className="grid grid-cols-6 gap-2">
                                                {ICONS.map(icon => (
                                                    <button
                                                        key={icon}
                                                        type="button"
                                                        onClick={() => handleChange('icon', icon)}
                                                        className={`p-3 text-2xl rounded-xl border-2 transition-all ${
                                                            formData.icon === icon
                                                                ? `border-${formData.color}-500 bg-${formData.color}-50 dark:bg-${formData.color}-900/30`
                                                                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                                                        }`}
                                                    >
                                                        {icon}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>

                                        {/* Couleur */}
                                        <div className="space-y-2">
                                            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300">
                                                Couleur
                                            </label>
                                            <div className="flex gap-2">
                                                {COLORS.map(color => (
                                                    <button
                                                        key={color.name}
                                                        type="button"
                                                        onClick={() => handleChange('color', color.name)}
                                                        className={`w-10 h-10 rounded-xl ${color.class} transition-all ${
                                                            formData.color === color.name
                                                                ? 'ring-4 ring-offset-2 ring-' + color.name + '-300 dark:ring-offset-gray-900 scale-110'
                                                                : 'hover:scale-105'
                                                        }`}
                                                    />
                                                ))}
                                            </div>
                                        </div>

                                        {/* Boutons */}
                                        <div className="flex gap-3 pt-4">
                                            <button
                                                type="button"
                                                onClick={onClose}
                                                className="flex-1 px-6 py-4 text-gray-600 dark:text-gray-400 font-semibold rounded-2xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
                                            >
                                                Annuler
                                            </button>
                                            <motion.button
                                                type="submit"
                                                disabled={!isValid || loading}
                                                whileHover={isValid ? { scale: 1.02 } : {}}
                                                whileTap={isValid ? { scale: 0.98 } : {}}
                                                className={`flex-1 px-6 py-4 rounded-2xl font-semibold text-white relative overflow-hidden group ${
                                                    isValid && !loading
                                                        ? `bg-gradient-to-r ${selectedColor.gradient} shadow-lg`
                                                        : 'bg-gray-300 dark:bg-gray-700 cursor-not-allowed'
                                                }`}
                                            >
                                                <div className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                                                {loading ? (
                                                    <div className="flex items-center justify-center gap-2">
                                                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                                        <span>Création en cours...</span>
                                                    </div>
                                                ) : (
                                                    <span className="flex items-center justify-center gap-2">
                                                        <Save className="w-5 h-5" />
                                                        Créer le pilier
                                                    </span>
                                                )}
                                            </motion.button>
                                        </div>
                                    </form>
                                )}
                            </div>
                        </motion.div>
                    </div>
                </div>
            )}
        </AnimatePresence>
    );
}
